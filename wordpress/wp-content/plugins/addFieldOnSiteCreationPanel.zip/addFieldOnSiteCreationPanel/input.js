(function($) {
    $(document).ready(function() {
        $('<tr class="form-field form-required"></tr>').append(
            $('<th scope="row">New field</th>')
        ).append(
            $('<td></td>').append(
                $('<select id="release-list"></select>')
            ).append(
                $('<p>Explanation about your new field</p>')
            )
        ).insertAfter('#wpbody-content table tr:eq(2)');



        
    });

     $.getJSON('../../cache/one.json', function(data) {
        var select = $('#release-list');
        $.each(data, function(key, val){
            $('<option/>').attr('value', val[key]["Id"]).html('cover ' + val[key]["Name"]).appendTo(select);
        });
        });

})(jQuery);